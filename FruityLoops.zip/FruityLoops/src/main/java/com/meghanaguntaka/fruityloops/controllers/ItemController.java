package com.meghanaguntaka.fruityloops.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.meghanaguntaka.fruityloops.models.Item;

@Controller
public class ItemController {

	@RequestMapping("/")
	public String index(Model model) {
		ArrayList<Item> fruits = new ArrayList<Item>();
		fruits.add(new Item("Apple", 4));
		fruits.add(new Item("Orange", 7));
		fruits.add(new Item("Banana", 0.8));
		fruits.add(new Item("Mango", 11));
		fruits.add(new Item("Pineapple", 15.3));
		model.addAttribute("fruits", fruits);
		return "index.jsp";
	}
}

