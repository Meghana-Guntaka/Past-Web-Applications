package com.meghanaguntaka.baby.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.meghanaguntaka.baby.models.LoginUser;
import com.meghanaguntaka.baby.models.Baby;
import com.meghanaguntaka.baby.models.User;
import com.meghanaguntaka.baby.services.BabyService;
import com.meghanaguntaka.baby.services.UserService;

@Controller
public class HomeController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BabyService babyService;
	
	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("newUser", new User());
		model.addAttribute("newLogin", new LoginUser());
		return "index.jsp";
	}
	
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("newUser") User newUser, BindingResult result, HttpSession session, Model model) {
		User user = userService.register(newUser, result);
		if(result.hasErrors()) {
			model.addAttribute("newLogin", new LoginUser());
			return "index.jsp";
		}else {
			session.setAttribute("userId", user.getId());
			session.setAttribute("userName", user.getUserName());
			return "redirect:/dashboard";
		}
	}
	
	@PostMapping("/login")
	public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, BindingResult result, HttpSession session, Model model) {
		User user = userService.login(newLogin, result);
		if(result.hasErrors()) {
			model.addAttribute("newUser", new User());
			return "index.jsp";
		}else {
			session.setAttribute("userId", user.getId());
			session.setAttribute("userName", user.getUserName());
			return "redirect:/dashboard";
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/dashboard")
	public String dashboard(HttpSession session, Model model) {
		if(session.getAttribute("userId")==null) {
			return "redirect:/";
		}else {
			model.addAttribute("babyList", babyService.allBabys());
			return "dashboard.jsp";
		}
	}
	
	// CREATE BABY
	
	@GetMapping("/babys/add")
	public String renderCreateBaby(@ModelAttribute("baby")Baby baby) {
		return "createBaby.jsp";
	}
	
	@PostMapping("/babys/add")
	public String processCreateBaby(@Valid @ModelAttribute("baby") Baby baby, BindingResult result) {
		if(result.hasErrors()) {
			return "createBaby.jsp";
		}else {
			babyService.saveBaby(baby);
			return "redirect:/dashboard";
		}
	}
	
	// SHOW DETAILS
	
	@GetMapping("/babys/{id}")
	public String babyDetails(@PathVariable("id")Long id, Model model) {
		model.addAttribute("oneBaby", babyService.oneBaby(id));
		return "babyDetails.jsp";
	}
	
	// DELETE
	
	@DeleteMapping("/babys/delete/{id}")
	public String deleteBaby(@PathVariable("id")Long id) {
		babyService.deleteBaby(id);
		return "redirect:/dashboard";
	}
	
	// EDIT BABY
	
	@GetMapping("/babys/edit/{id}")
	public String renderEditBaby(@PathVariable("id")Long id, Model model) {
		model.addAttribute("baby", babyService.oneBaby(id));
		return "editBaby.jsp";
	}
	
	@PutMapping("/babys/edit/{id}")
	public String processEditBaby(@Valid @ModelAttribute("baby") Baby baby, BindingResult result) {
		if(result.hasErrors()) {
			return "editBaby.jsp";
		}else {
			babyService.saveBaby(baby);
			return "redirect:/dashboard";
		}
	}
	
}
