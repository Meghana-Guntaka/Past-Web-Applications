package com.meghanaguntaka.baby.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.meghanaguntaka.baby.repositories.BabyRepository;
import com.meghanaguntaka.baby.models.Baby;

@Service
public class BabyService {
	
	@Autowired
	private BabyRepository babyRepo;
	
	public List<Baby> allBabys(){
		return babyRepo.findAll();
	}
		
	public Baby oneBaby(Long id) {
		Optional<Baby> optionalBaby = babyRepo.findById(id);
		if(optionalBaby.isPresent()) {
			return optionalBaby.get();
		}else {
			return null;
		}
	}
	
	public Baby saveBaby(Baby baby) {
		return babyRepo.save(baby);
	}
	
	public void deleteBaby(Long id) {
		babyRepo.deleteById(id);
	}
}
