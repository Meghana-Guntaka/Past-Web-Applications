package com.meghanaguntaka.baby;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamBabyNamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamBabyNamesApplication.class, args);
	}

}
