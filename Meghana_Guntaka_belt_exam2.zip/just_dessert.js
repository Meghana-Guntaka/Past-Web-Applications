function hide(element) {
    element.remove();
}

document.body.addEventListener('click', (event) => {
    const button = event.target.closest('.button');
    const container = button.closest('.likes');
    const counter = container.querySelector('.counter');
    counter.innerText = Number(counter.innerText) + 1;
});
