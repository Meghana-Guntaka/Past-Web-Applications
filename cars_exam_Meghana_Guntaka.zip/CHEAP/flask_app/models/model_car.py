from flask_app import app
from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import cars_erd
from flask_app.models.model_user import User

class Car:
    def __init__(self, data):
        self.id = data['id']
        self.price = data['price']
        self.model = data['model']
        self.make = data['make']
        self.year = data['year']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data['user_id']


    @classmethod
    def add_car(cls, data):
        query = "INSERT INTO cars (price, model, make, year, description, user_id) VALUES (%(price)s, %(model)s, %(make)s, %(year)s, %(description)s, %(user_id)s);"
        return connectToMySQL(cars_erd).query_db(query, data)


    @classmethod
    def show_all(cls):
        query = "SELECT * FROM cars"
        results = connectToMySQL(cars_erd).query_db(query)

        if results:
            all_cars = []
            for car in results:
                all_cars.append(cls(car))
            return all_cars
        return []

    @classmethod
    def show_one(cls, data):
        query = "SELECT * FROM cars WHERE id = %(id)s"
        results = connectToMySQL(cars_erd).query_db(query, data)
        return cls(results[0])

    @classmethod
    def show_car_with_user(cls, data):
        query = "SELECT * FROM cars LEFT JOIN users ON users.id = cars.user_id WHERE cars.id = %(id)s;"
        results = connectToMySQL(cars_erd).query_db(query, data)
        row=results[0]
        car = cls(row)
        user_data = {
            'id': row['users.id'],
            'first_name': row['first_name'],
            'last_name': row['last_name'],
            'email': row['email'],
            'password': row['password'],
            'created_at': row['users.created_at'],
            'updated_at': row['users.updated_at']
        }
        car.user = User(user_data) 
        # car instance adding new attribute to it, and creating a user instance
        return car


    @classmethod
    def edit_car(cls, data):
        query = "UPDATE cars SET price = %(price)s, model = %(model)s, make = %(make)s, year = %(year)s, description = %(description)s, updated_at = NOW() WHERE id = %(id)s;"
        return connectToMySQL(cars_erd).query_db(query, data)


    @classmethod
    def delete_car(cls, data):
        query = "DELETE FROM cars WHERE id = %(id)s"
        return connectToMySQL(cars_erd).query_db(query, data)

    @staticmethod
    def validate_car(data):
        is_valid = True
        if len(data['price']) < 1:
            flash("Car price must be greater than 0.")
            is_valid = False
        if len(data['year']) < 1:
            flash("Car year must be greater than 0.")
            is_valid = False
        if not data['price']:
            flash("All fields required.")
            is_valid = False
        if not data['model']:
            flash("All fields required.")
            is_valid = False
        if not data['make']:
            flash("All fields required.")
            is_valid = False
        if not data['year']:
            flash("All fields required.")
            is_valid = False
        if not data['description']:
            flash("All fields required.")
            is_valid = False
        return is_valid