from flask_app import app
from flask import render_template, request, redirect, session, flash
from flask_app.models.model_user import User
from flask_app.models.model_car import Car

@app.route('/car/form')
def show_car_form():
    if not 'user_id' in session:
        flash("You must be logged in to view this page")
        return redirect('/')

    return render_template('add_car.html')


@app.route('/show/car/<int:id>')
def show_one_car(id):
    if not 'user_id' in session:
        flash("You must be logged in to view this page")
        return redirect('/')
    data = {
        'id': id
    }
    car = Car.show_car_with_user(data)
    user = User.get_user_by_id({'id': session['user_id']})
    return render_template('show_car.html', car = car, user = user)


@app.route('/add/car', methods=['POST'])
def add_show():
    if not Car.validate_car(request.form):
        return redirect('/car/form')
    data = {
        'price': request.form['price'],
        'model': request.form['model'],
        'make': request.form['make'],
        'year': request.form['year'],
        'description': request.form['description'],
        'user_id' : session['user_id']
    }
    Car.add_car(data)
    return redirect('/dashboard')


@app.route('/edit/form/<int:id>')
def edit_car(id):
    if not 'user_id' in session:
        flash("You must be logged in to view this page")
        return redirect('/')
    data = {
        'id': id
    }
    car = Car.show_car_with_user(data)
    return render_template('edit_car.html', car = car)


@app.route('/edit/car/<int:id>', methods=['POST'])
def update_car(id):
    if not Car.validate_car(request.form):
        return redirect(f"/edit/form/{id}")
    data = {
        'id': request.form['id'],
        'price': request.form['price'],
        'model': request.form['model'],
        'make': request.form['make'],
        'year': request.form['year'],
        'description': request.form['description'],
    }
    Car.edit_car(data)
    return redirect('/dashboard')


@app.route('/delete/car/<int:id>', methods=['GET'])
def delete_car(id):
    if not 'user_id' in session:
        flash("You must be logged in to view this page")
        return redirect('/')
    data = {
        'id': id
    }
    Car.delete_car(data)
    return redirect('/dashboard')